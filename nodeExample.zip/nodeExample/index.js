const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const {v4:uuidv4} = require('uuid');
const bcrypt = require('bcrypt');

const dbSource = 'node.db';
const db = new sqlite3.Database(dbSource);

const HTTP_PORT = 8000;


var app = express();
app.use(cors());



class Fruit {
    constructor(strName, strColor){
        this.name = strName;
        this.color = strColor;
    }
}

let strID = uuidv4();

var arrFruit = [];
let objBanana = new Fruit('banana', 'yellow');
let objApple = new Fruit('apple', 'red');
let objGrape = new Fruit('grape', 'green');

arrFruit.push(objBanana);
arrFruit.push(objApple);
arrFruit.push(objGrape);
arrFruit.push(new Fruit('kiwi', 'brown'));


app.get('/', (req, res, next) => {
    res.status(200).send(arrFruit);
})


app.get('/fruit/:name', (req, res, next) => {
    let strName = req.params.name;
    if(strName) {
        let strCommand = "select * from tblFruit where name = ?";
        let arrParameters = [strName];
        db.all(strCommand, arrParameters, (err, row) => {
            if(err) {
                res.status(400).json({error: err.message});
            } else {
                if(row.length < 1) {
                    res.status(200).json({error: 'error: not found'})
                } else {
                    res.status(200).json({message: 'success', fruit: row});
                }
            }
        })
    } else {
        res.status(400).json({error: 'No fruit name provided'})
    }
})


app.delete('/fruit', (req, res, next) => {
    let strName = req.query.name;
    if(strName) {
        arrFruit.forEach(function(fruit, index) {
            if(fruit.name == strName) {
                arrFruit.splice(index, -1);
                res.status(200).send(fruit)
            }
        })
        res.status(200).send({'Error': 'Fruit not found'})
    } else {

        arrFruit = [];

        res.status(200).send(arrFruit);
    }
})


app.post('/fruit', (req, res, next) => {
    let strName = req.query.name;
    let strColor = req.query.color;

    let strCommand = "insert into tblFruit values(?, ?)";
    if(strName && strColor) {
        let arrParameters = [strName, strColor];
        let objFruit = new Fruit(strName, strColor);
        db.run(strCommand, arrParameters, (err, result) => {
            if(err) {
                res.status(400).json({error: err.message});
            } else {
                res.status(201).json({message: 'success', fruit: objFruit})
            }
        })
    } else {
        res.status(400).json({error: 'not all parameters provided'})
    }
})


app.post("/users",(req,res,next) => {
    let strEmail = req.query.email;
    let strPassword = req.query.password;
    if(strEmail && strPassword){
        bcrypt.hash(strPassword, 10).then(hash => {
            strPassword = hash;
            let strCommand = "INSERT INTO tblUsers VALUES(?,?)";
            let arrParameters = [strEmail,strPassword];
            db.run(strCommand,arrParameters,function(err,result){
                if(err){
                    res.status(400).json({error:err.message})
                } else {
                    res.status(201).json({
                        message:"success",
                        email:strEmail
                    })
                }
            })
        })
    } else {
        res.status(400).json({error:"Not all parameters provided"})
    }
    
})

app.post("/sessions",(req,res,next) => {
    let strEmail = req.query.email;
    let strPassword = req.query.password;
    let strSessionID = uuidv4();
    if(strEmail && strPassword){
        bcrypt.hash(strPassword, 10).then(hash => {
            strPassword = hash;
            let strCommand = "SELECT * FROM tblUsers WHERE Email = ? AND Password = ?";
            let arrParameters = [strEmail,strPassword];
            db.all(strCommand,arrParameters,function(err,result){
                if(result.length > 0){
                    strCommand = "INSERT INTO tblSessions VALUES(?,?)";
                    arrParameters = [strSessionID,strEmail];
                    db.run(strCommand,arrParameters,function(err,result){
                        if(err){
                            res.status(400).json({error:err.message})
                        } else {
                            res.status(201).json({
                                message:"success",
                                sessionid:strSessionID
                            })
                        }
                    })
                }
            })
            
        })
    } else {
        res.status(400).json({error:"Not all parameters provided"})
    }
    
})

app.get("/hello", (req, res, next) => {

    let strCommand = 'select * from tblFruit';

    db.all(strCommand, (err, row) => {
        if(err) {
            res.status(400).json({error: err.message});
        } else {
             res.status(200).json({message: 'Success', fruit: row});
        }
    })


   
})


app.listen(HTTP_PORT);
console.log(`Listening on port ${HTTP_PORT}`);
